﻿using Microsoft.EntityFrameworkCore;
using HospitalManagementAPII.Models;

namespace HospitalManagementAPII.Data
{
    public class HospitalManagementContext : DbContext
    {
        public HospitalManagementContext(DbContextOptions<HospitalManagementContext> options) : base(options) { }

        public DbSet<Patient> Patients { get; set; }
        public DbSet<Doctor> Doctors { get; set; }
    }
}
