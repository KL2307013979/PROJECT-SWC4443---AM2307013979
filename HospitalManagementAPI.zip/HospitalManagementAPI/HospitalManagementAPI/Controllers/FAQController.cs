﻿using Microsoft.AspNetCore.Mvc;

public class FAQController : Controller
{
    public IActionResult Index()
    {
        return View();  // Will return the Index.cshtml view from Views/FAQ/
    }
}