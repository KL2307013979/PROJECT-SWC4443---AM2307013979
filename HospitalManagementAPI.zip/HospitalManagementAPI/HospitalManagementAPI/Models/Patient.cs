﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HospitalManagementAPI.Models
{
    public class Patient
    {
        [Key]
        public int PatientID { get; set; }

        [Required(ErrorMessage = "Patient name is required.")]
        [MaxLength(100, ErrorMessage = "Patient name cannot exceed 100 characters.")]
        [Display(Name = "Patient Name")]
        public string PatientName { get; set; }

        [DataType(DataType.Date)]
        [Required]
        [CustomValidation(typeof(Patient), nameof(ValidateDOB))]
        [Display(Name = "Date of Birth")]
        public DateTime DOB { get; set; }

        [Phone]
        [MaxLength(100)]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email address.")]
        [MaxLength(100, ErrorMessage = "Email cannot exceed 100 characters.")]
        public string Email { get; set; }

        public static ValidationResult ValidateDOB(DateTime dob, ValidationContext context)
        {
            if (dob >= DateTime.Today)
            {
                return new ValidationResult("Date of Birth must be in the past.");
            }
            return ValidationResult.Success;
        }
    }
}